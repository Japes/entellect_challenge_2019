#include "GameConfig.hpp"

const int GameConfig::maxRounds;
const int GameConfig::maxDoNothings;
const CommandoWorms GameConfig::commandoWorms;
const int GameConfig::pushbackDamage;
const int GameConfig::mapSize;
const int GameConfig::healthPackHp;
const int GameConfig::totalHealthPacks;
const Scores GameConfig::scores;
