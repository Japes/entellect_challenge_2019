#include "DigCommand.hpp"
#include "DoNothingCommand.hpp"
#include "ShootCommand.hpp"
#include "TeleportCommand.hpp"