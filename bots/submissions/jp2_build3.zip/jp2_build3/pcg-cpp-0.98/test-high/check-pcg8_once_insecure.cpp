#define RNG pcg8_once_insecure
#define TWO_ARG_INIT 1

#include "pcg-test.cpp"

