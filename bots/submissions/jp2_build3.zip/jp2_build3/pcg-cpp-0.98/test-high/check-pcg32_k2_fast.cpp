#define RNG pcg32_k2_fast
#define TWO_ARG_INIT 0

#include "pcg-test.cpp"

